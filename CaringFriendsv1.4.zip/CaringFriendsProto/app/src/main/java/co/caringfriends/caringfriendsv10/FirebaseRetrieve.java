package co.caringfriends.caringfriendsv10;

import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Mark on 6/13/2017.
 */

public class FirebaseRetrieve {

    /**
     *
     * @return an arraylist full of our retrieved data.  Just moving it out of our fragment to make it more readable.
     * @param query Please keep in mind that this will only work for data matching the style of questions and observations in the database.
     *              Anything else will have strange results.
     */

    public static ArrayList<question> retrieveData(String query){

        //Simply a placeholder list.  This has been abstracted.
        final ArrayList<question> questions = new ArrayList<>();
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        //returns the reference to our entire database
        //we must then add child references to this
        final DatabaseReference databaseReference = database.getReference();

        //this is our child reference of our database.  We can call methods on this
        //and set listeners without crashing our app
        final DatabaseReference optionsArrayRef = databaseReference.child("user0").child(query);
        optionsArrayRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //Getting our arraylist of our questions.  We need to loop over this to extract our data and construct our objects
                //Keep in mind you need to cast objects with elements and cant use generics.
                //These have been found to be arraylists of hashmaps.  So matrices.
                ArrayList<Object> listOfQuestions = (ArrayList<Object>)dataSnapshot.getValue();

                for(int i = 0; i<listOfQuestions.size(); i++) {
                    //Each of these is a hashmap, again we cannot have a generic call, we use object for our value
                    //because it could be anything, but our keys are always strings
                    HashMap<String, Object> question = (HashMap<String, Object>)listOfQuestions.get(i);
                    Log.v("Question:", question.toString());

                    //I know it's going to be a string behind every format key, so we can cast it to String.  We can also
                    //grab our question text since every question has one and we know it's a string.
                    String questionFormat = (String)question.get("format");
                    String questionText = (String)question.get("text");

                    //now we need to split the code depending on whether its an open-ended or multiple-choice question
                    if(questionFormat.equals("openEnded")) {
                        questions.add(new openQuestion(questionText));
                    }
                    //The question must be multiple choice then
                    else {
                        //set up an arraylist of type String
                        ArrayList<String> options = (ArrayList<String>) question.get("options");
                        switch(options.size()){
                            case 2:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1)));
                                break;
                            case 3:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1), options.get(2)));
                                break;
                            case 4:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1), options.get(2), options.get(3)));
                                break;
                            default:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1)));
                                break;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        return questions;
    }

}
