package co.caringfriends.caringfriendsv10;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Mark on 6/13/2017.
 */

public class ObservationsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.list_layout, container, false);

        //get the arraylist that we loaded in the previous viewPager activity
        ArrayList<question> observations = (ArrayList<question>)getActivity().getIntent().getExtras().getSerializable("observationsList");

        questionAdapter adapter = new questionAdapter(getActivity(), observations);

        ListView listView = (ListView)rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }
}
