package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Displays a {@link ViewPager} where each page shows a different day of the week.
 */
public class InformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        final TabLayout tabLayout = (TabLayout)findViewById(R.id.tab_layout);

        //Get our adapter to fit these fragments to our activity
        InformationFragmentPagerAdapter infoAdapter = new InformationFragmentPagerAdapter(getSupportFragmentManager());

        //Add in our tabs to our top bar
        tabLayout.addTab(tabLayout.newTab().setText("Personal Info").setIcon(R.drawable.ic_account_circle_white_24dp));
        tabLayout.addTab(tabLayout.newTab().setText("Useful Info").setIcon(R.drawable.ic_local_hospital_white_24dp));

        final ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setAdapter(infoAdapter);

        //TODO: Need to define this listener elsewhere so we can remove it in the onclick of button
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tabLayout.getSelectedTabPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}
