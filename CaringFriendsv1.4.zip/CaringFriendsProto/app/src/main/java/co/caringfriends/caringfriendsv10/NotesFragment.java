package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

/**
 * Created by Mark on 6/13/2017.
 */

public class NotesFragment extends Fragment {

    static final int REQUEST_VIDEO_CAPTURE = 1;
    static final int REQUEST_IMAGE_CAPTURE = 2;
    Uri photoURI = null;
    Uri videoURI = null;
    private String videoDownloadUrl;
    private String imageDownloadUrl;
    private StorageReference imageRef;
    private StorageReference videoRef;

    View rootView;

    private FirebaseAuth mAuth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_notes, container, false);

        //Sign in our user anonymously for the time being.  This is set in firebase.
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signInAnonymously();

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference mStorageRef = storage.getReferenceFromUrl("gs://caringfriends-9d3c4.appspot.com");

        //Generate placeholder references for our incoming image and video
        videoRef = mStorageRef.child("Video");
        imageRef = mStorageRef.child("Image");

        Button notesButton = (Button)rootView.findViewById(R.id.notesButton);
        notesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //could we use a json to pdf api to generate a pdf of the file, add that to storage,
                //and then send an additional url of that? Might be cool.
                String videoPresentString = "";
                String imagePresentString = "";

                //if video was attached, get and attach the url to the email
                if(videoDownloadUrl != null){
                    videoPresentString = "\n\nYour relative decided to send you a video.  " +
                            "You may view it at the link below.\n\n" + videoDownloadUrl;
                }

                //if image was attached, get and attach the url to the email
                if(imageDownloadUrl != null){
                    imagePresentString = "\n\nYou have an image of your relative waiting for you.  " +
                            "Click the link below to view.\n\n" + imageDownloadUrl;
                }

                //create the intent, and attach our strings
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto","caring@caringfriends.co", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Visit Picture");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Greeting from your friends at Caring Friends.  " +
                        "Your relative just concluded a visit with one of our team members.  " +
                        "You may view their observations online via your account login.  If your relative  " +
                        "provided a picture or video for you to view, a link to it will be given below.  " +
                        videoPresentString + imagePresentString);
                startActivity(Intent.createChooser(emailIntent, "Send email..."));
            }
        });

        Button videoButton = (Button)rootView.findViewById(R.id.videoButton);
        videoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakeVideoIntent();
            }
        });

        Button pictureButton = (Button)rootView.findViewById(R.id.pictureButton);
        pictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

        return rootView;
    }



    public void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        takeVideoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT,30);
        startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //determine which type of intent was invoked and respond accordingly
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            photoURI = data.getData();
        }
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == Activity.RESULT_OK) {
            videoURI = data.getData();
        }

        //enter our file into firebase storage and send us a url to get it
        if (videoURI != null) {
            videoRef.putFile(videoURI)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            videoDownloadUrl = taskSnapshot.getDownloadUrl().toString();
                        }
                    });
            //not going to handle a failure of code for right now
        }

        if (photoURI != null){
            imageRef.putFile(photoURI)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            imageDownloadUrl = taskSnapshot.getDownloadUrl().toString();
                        }
                    });
        }
    }
}