package co.caringfriends.caringfriendsv10;

import java.io.Serializable;

/**
 * This is the superclass of both multiQuestion and openQuestion.  Attempting to implement into one listview.
 * Created by Mark on 6/8/2017.
 */

//let us pass this through intents using serializable
public class question implements Serializable{

    private String mQuestionText;
    private String mObjectType;

    public String getmQuestionText(){
        return mQuestionText;
    }

    public void setmQuestionText(String questionText) {
        mQuestionText = questionText;
    }

    //open-ended question constructor
    question(String questionText) {
        mQuestionText = questionText;
        mObjectType = "openEnded";
    }

    //multi-choice question constructors
    question(String questionText, String option1, String option2, String option3, String option4) {
        mQuestionText = questionText;
        mObjectType = "multiChoice";
    }

    question(String questionText, String option1, String option2, String option3) {
        mQuestionText = questionText;
        mObjectType = "multiChoice";
    }

    question(String questionText, String option1, String option2) {

        mQuestionText = questionText;
        mObjectType = "multiChoice";
    }

    public String getmObjectType() {
        return mObjectType;
    }

}