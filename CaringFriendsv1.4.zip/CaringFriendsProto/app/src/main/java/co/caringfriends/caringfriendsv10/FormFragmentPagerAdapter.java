package co.caringfriends.caringfriendsv10;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Mark on 6/13/2017.
 */

public class FormFragmentPagerAdapter extends FragmentPagerAdapter {

    public FormFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    //deliver the correct frragment
    @Override
    public Fragment getItem(int position) {
        if(position == 0){
            return new QuestionsFragment();
        } else if (position == 1){
            return new ObservationsFragment();
        } else {
            return new NotesFragment();
        }
    }

    //we know how many tabs we have, so we'll just hand that in
    @Override
    public int getCount() {
        return 3;
    }
}
