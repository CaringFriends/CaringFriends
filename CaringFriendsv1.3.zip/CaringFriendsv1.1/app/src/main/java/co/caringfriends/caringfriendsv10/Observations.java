package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class Observations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_observations);

        //ESTABLISH RETROFIT DATA CONNECTION
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://docs.google.com/forms/d/")
                .build();
        final WebConnect spreadsheetWebService = retrofit.create(WebConnect.class);

        findViewById(R.id.observationsButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK FROM PREVIOUS ACTIVITY
                String message = getIntent().getExtras().getString("Message");

                //FIND ALL OF THE RADIO GROUPS
                RadioGroup observation1Group = (RadioGroup) findViewById(R.id.observation1);
                RadioGroup observation2Group = (RadioGroup) findViewById(R.id.observation2);
                RadioGroup observation3Group = (RadioGroup) findViewById(R.id.observation3);
                RadioGroup observation4Group = (RadioGroup) findViewById(R.id.observation4);
                RadioGroup observation5Group = (RadioGroup) findViewById(R.id.observation5);
                RadioGroup observation6Group = (RadioGroup) findViewById(R.id.observation6);
                RadioGroup observation7Group = (RadioGroup) findViewById(R.id.observation7);
                RadioGroup observation8Group = (RadioGroup) findViewById(R.id.observation8);
                RadioGroup observation9Group = (RadioGroup) findViewById(R.id.observation9);
                RadioGroup observation10Group = (RadioGroup) findViewById(R.id.observation10);
                RadioGroup observation11Group = (RadioGroup) findViewById(R.id.observation11);
                RadioGroup observation12Group = (RadioGroup) findViewById(R.id.observation12);
                RadioGroup observation13Group = (RadioGroup) findViewById(R.id.observation13);
                RadioGroup observation14Group = (RadioGroup) findViewById(R.id.observation14);

                //FIND THE CHECKED RADIO BUTTONS
                RadioButton observation1Checked = (RadioButton) findViewById(observation1Group.getCheckedRadioButtonId());
                RadioButton observation2Checked = (RadioButton) findViewById(observation2Group.getCheckedRadioButtonId());
                RadioButton observation3Checked = (RadioButton) findViewById(observation3Group.getCheckedRadioButtonId());
                RadioButton observation4Checked = (RadioButton) findViewById(observation4Group.getCheckedRadioButtonId());
                RadioButton observation5Checked = (RadioButton) findViewById(observation5Group.getCheckedRadioButtonId());
                RadioButton observation6Checked = (RadioButton) findViewById(observation6Group.getCheckedRadioButtonId());
                RadioButton observation7Checked = (RadioButton) findViewById(observation7Group.getCheckedRadioButtonId());
                RadioButton observation8Checked = (RadioButton) findViewById(observation8Group.getCheckedRadioButtonId());
                RadioButton observation9Checked = (RadioButton) findViewById(observation9Group.getCheckedRadioButtonId());
                RadioButton observation10Checked = (RadioButton) findViewById(observation10Group.getCheckedRadioButtonId());
                RadioButton observation11Checked = (RadioButton) findViewById(observation11Group.getCheckedRadioButtonId());
                RadioButton observation12Checked = (RadioButton) findViewById(observation12Group.getCheckedRadioButtonId());
                RadioButton observation13Checked = (RadioButton) findViewById(observation13Group.getCheckedRadioButtonId());
                RadioButton observation14Checked = (RadioButton) findViewById(observation14Group.getCheckedRadioButtonId());


                //CHECK FOR ANY NULL RADIOBUTTONS CREATED
                if (
                        observation1Checked != null && observation2Checked != null &&
                                observation3Checked != null && observation4Checked != null &&
                                observation5Checked != null && observation6Checked != null &&
                                observation7Checked != null && observation8Checked != null &&
                                observation9Checked != null && observation10Checked != null &&
                                observation11Checked != null && observation12Checked != null &&
                                observation13Checked != null && observation14Checked != null
                        )
                {
                    //FIND THE TEXTVIEWS
                    TextView observation1TextView = (TextView) findViewById(R.id.observation1Text);
                    TextView observation2TextView = (TextView) findViewById(R.id.observation2Text);
                    TextView observation3TextView = (TextView) findViewById(R.id.observation3Text);
                    TextView observation4TextView = (TextView) findViewById(R.id.observation4Text);
                    TextView observation5TextView = (TextView) findViewById(R.id.observation5Text);
                    TextView observation6TextView = (TextView) findViewById(R.id.observation6Text);
                    TextView observation7TextView = (TextView) findViewById(R.id.observation7Text);
                    TextView observation8TextView = (TextView) findViewById(R.id.observation8Text);
                    TextView observation9TextView = (TextView) findViewById(R.id.observation9Text);
                    TextView observation10TextView = (TextView) findViewById(R.id.observation10Text);
                    TextView observation11TextView = (TextView) findViewById(R.id.observation11Text);
                    TextView observation12TextView = (TextView) findViewById(R.id.observation12Text);
                    TextView observation13TextView = (TextView) findViewById(R.id.observation13Text);
                    TextView observation14TextView = (TextView) findViewById(R.id.observation14Text);

                    //CONCATENATE THOSE STRINGS
                    message += addToMessage(concatenateRadio(observation1TextView, observation1Checked));
                    message += addToMessage(concatenateRadio(observation2TextView, observation2Checked));
                    message += addToMessage(concatenateRadio(observation3TextView, observation3Checked));
                    message += addToMessage(concatenateRadio(observation4TextView, observation4Checked));
                    message += addToMessage(concatenateRadio(observation5TextView, observation5Checked));
                    message += addToMessage(concatenateRadio(observation6TextView, observation6Checked));
                    message += addToMessage(concatenateRadio(observation7TextView, observation7Checked));
                    message += addToMessage(concatenateRadio(observation8TextView, observation8Checked));
                    message += addToMessage(concatenateRadio(observation9TextView, observation9Checked));
                    message += addToMessage(concatenateRadio(observation10TextView, observation10Checked));
                    message += addToMessage(concatenateRadio(observation11TextView, observation11Checked));
                    message += addToMessage(concatenateRadio(observation12TextView, observation12Checked));
                    message += addToMessage(concatenateRadio(observation13TextView, observation13Checked));
                    message += addToMessage(concatenateRadio(observation14TextView, observation14Checked));

                    Intent intent = new Intent(Observations.this, Notes.class);

                    Call<Void> completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(message);
                    completeQuestionnaireCall.enqueue(callCallback);

                    intent.putExtra("Message", message);
                    startActivity(intent);
                }

            else{
                    Toast.makeText(Observations.this, "Oops! Looks like you missed a question.", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    private String concatenateRadio(TextView question, RadioButton response)
    {
        return (question.getText().toString() + "\n" + response.getText().toString());
    }

    private final Callback<Void> callCallback = new Callback<Void>() {
        @Override
        public void onResponse(Response<Void> response) {
            Log.d("XXX", "Submitted. " + response);
        }

        @Override
        public void onFailure(Throwable t) {
            Log.e("XXX", "Failed", t);
        }
    };

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private String addToMessage(String questionFull){
        return "\n\n" + questionFull;
    }
}