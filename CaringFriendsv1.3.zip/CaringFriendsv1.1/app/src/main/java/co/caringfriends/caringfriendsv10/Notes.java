package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.File;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Notes extends AppCompatActivity {

    static final int REQUEST_VIDEO_CAPTURE = 1;
    static final int REQUEST_IMAGE_CAPTURE = 2;
    Uri photoURI = null;
    Uri videoURI = null;
    File photoFile = null;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myReference = database.getReference("Report");

    private StorageReference imageRef;
    private StorageReference videoRef;
    private StorageReference mStorageRef;

    //This will be the string that the firebase console returns for us to access our video/image
    String urlVideoString = null;
    String urlImageString = null;

    //generate null values for our urls that might get overwritten
    Uri videoDownloadUrl = null;
    Uri imageDownloadUrl = null;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //set our default font to be roboto
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_notes);

        //Retrieve our intent message
        final String message = getIntent().getExtras().getString("Message");

        //Sign in our user anonymously for the time being.  This is set in firebase.
        mAuth = FirebaseAuth.getInstance();
        mAuth.signInAnonymously();

        FirebaseStorage storage = FirebaseStorage.getInstance();
        mStorageRef = storage.getReferenceFromUrl("gs://caringfriends-9d3c4.appspot.com");

        //Generate placeholder references for our incoming image and video
        videoRef = mStorageRef.child("Video");
        imageRef = mStorageRef.child("Image");

        Button notesButton = (Button)findViewById(R.id.notesButton);
        notesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //could we use a json to pdf api to generate a pdf of the file, add that to storage,
                //and then send an additional url of that? Might be cool.
                myReference.setValue(message);
                String videoPresentString = "";
                String imagePresentString = "";
                if(videoDownloadUrl != null){
                    videoPresentString = "\n\nYour relative decided to send you a video.  " +
                            "You may view it at the link below.\n\n" + urlVideoString;
                }
                if(imageDownloadUrl != null){
                    imagePresentString = "\n\nYou have an image of your relative waiting for you.  " +
                            "Click the link below to view.\n\n" + urlImageString;
                }
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto","caring@caringfriends.co", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Visit Picture");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Greeting from your friends at Caring Friends.  " +
                        "Your relative just concluded a visit with one of our team members.  " +
                        "You may view their observations online via your account login.  If your relative  " +
                        "provided a picture or video for you to view, a link to it will be given below.  " +
                        videoPresentString + imagePresentString);
                //if (photoURI != null) {emailIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(photoFile));}
                //if (videoURI != null) {emailIntent.putExtra(Intent.EXTRA_STREAM, videoURI);}
                startActivity(Intent.createChooser(emailIntent, "Send email..."));
            }
        });

        Button videoButton = (Button)findViewById(R.id.videoButton);
        videoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakeVideoIntent();
            }
        });

        Button pictureButton = (Button)findViewById(R.id.pictureButton);
        pictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        ImageView thumbnail = (ImageView)findViewById(R.id.thumbnail);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            thumbnail.setImageBitmap(imageBitmap);
            photoURI = data.getData();
        }
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
            videoURI = data.getData();
        }

        //enter our file into firebase storage and send us a url to get it
        if(videoURI != null){
            videoRef.putFile(videoURI)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            videoDownloadUrl = taskSnapshot.getDownloadUrl();
                            urlVideoString = videoDownloadUrl.toString();
                        }
                    });
            //not going to handle a failure of code for right now
        }

        if (photoURI != null){
            imageRef.putFile(photoURI)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            imageDownloadUrl = taskSnapshot.getDownloadUrl();
                            urlImageString = imageDownloadUrl.toString();
                        }
                    });
        }
    }

    private void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        takeVideoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT,30);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
        }
    }
}