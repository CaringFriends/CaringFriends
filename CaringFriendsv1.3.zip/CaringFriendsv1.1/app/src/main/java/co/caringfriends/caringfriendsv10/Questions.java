package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Questions extends AppCompatActivity {

    String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_questions);

        //FIND ALL OF THE RADIOGROUPS
        final RadioGroup question1Group = (RadioGroup) findViewById(R.id.question1);
        final RadioGroup question2Group = (RadioGroup) findViewById(R.id.question2);
        final RadioGroup question3Group = (RadioGroup) findViewById(R.id.question3);
        final RadioGroup question4Group = (RadioGroup) findViewById(R.id.question4);
        final RadioGroup question5Group = (RadioGroup) findViewById(R.id.question5);
        final RadioGroup question6Group = (RadioGroup) findViewById(R.id.question6);
        final RadioGroup question7Group = (RadioGroup) findViewById(R.id.question7);
        final RadioGroup question8Group = (RadioGroup) findViewById(R.id.question8);
        final RadioGroup question9Group = (RadioGroup) findViewById(R.id.question9);
        final RadioGroup question10Group = (RadioGroup) findViewById(R.id.question10);
        final RadioGroup question11Group = (RadioGroup) findViewById(R.id.question11);
        final RadioGroup question12Group = (RadioGroup) findViewById(R.id.question12);
        final RadioGroup question13Group = (RadioGroup) findViewById(R.id.question13);
        final RadioGroup question14Group = (RadioGroup) findViewById(R.id.question14);
        final RadioGroup question15Group = (RadioGroup) findViewById(R.id.question15);
        final RadioGroup question16Group = (RadioGroup) findViewById(R.id.question16);
        final RadioGroup question17Group = (RadioGroup) findViewById(R.id.question17);
        final RadioGroup question18Group = (RadioGroup) findViewById(R.id.question18);
        final RadioGroup question19Group = (RadioGroup) findViewById(R.id.question19);
        final RadioGroup question20Group = (RadioGroup) findViewById(R.id.question20);
        final RadioGroup question21Group = (RadioGroup) findViewById(R.id.question21);
        final RadioGroup question22Group = (RadioGroup) findViewById(R.id.question22);
        final RadioGroup question23Group = (RadioGroup) findViewById(R.id.question23);
        final RadioGroup question24Group = (RadioGroup) findViewById(R.id.question24);

        //FIND ALL OF THE EDITTEXT
        final EditText question1Part2EditText = (EditText) findViewById(R.id.question1Part2EditText);
        final EditText question3Part2EditText = (EditText) findViewById(R.id.question3Part2EditText);
        final EditText question13Part2EditText = (EditText) findViewById(R.id.question13Part2EditText);
        final EditText question20Part2EditText = (EditText) findViewById(R.id.question20Part2EditText);
        final EditText question24Part2EditText = (EditText) findViewById(R.id.question24Part2EditText);
        final EditText question25EditText = (EditText) findViewById(R.id.question25EditText);

        final TextView question1Part2TextView = (TextView) findViewById(R.id.question1Part2Text);
        final TextView question3Part2TextView = (TextView) findViewById(R.id.question3Part2Text);

        final TextView question20Part2TextView = (TextView) findViewById(R.id.question20Part2Text);
        final TextView question24Part2TextView = (TextView) findViewById(R.id.question24Part2Text);

        question1Part2EditText.setVisibility(View.GONE);
        question1Part2TextView.setVisibility(View.GONE);

        question3Part2EditText.setVisibility(View.GONE);
        question3Part2TextView.setVisibility(View.GONE);

        question20Part2EditText.setVisibility(View.GONE);
        question20Part2TextView.setVisibility(View.GONE);

        question24Part2EditText.setVisibility(View.GONE);
        question24Part2TextView.setVisibility(View.GONE);

        question1Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question1Group.getCheckedRadioButtonId() == R.id.question1R4){
                    question1Part2EditText.setText("N/A");
                    question1Part2EditText.setVisibility(View.GONE);
                    question1Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question1Part2EditText.setVisibility(View.VISIBLE);
                    question1Part2EditText.setText("");
                    question1Part2TextView.setVisibility(View.VISIBLE);
                }
            }
        });

        question3Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question3Group.getCheckedRadioButtonId() != R.id.question3R5) {
                    question3Part2EditText.setVisibility(View.GONE);
                    question3Part2EditText.setText("N/A");
                    question3Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question3Part2EditText.setVisibility(View.VISIBLE);
                    question3Part2EditText.setText("");
                    question3Part2TextView.setVisibility(View.VISIBLE);

                }
            }
        });

        question20Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question20Group.getCheckedRadioButtonId() != R.id.question20R1) {
                    question20Part2EditText.setVisibility(View.GONE);
                    question20Part2EditText.setText("N/A");
                    question20Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question20Part2EditText.setVisibility(View.VISIBLE);
                    question20Part2EditText.setText("");
                    question20Part2TextView.setVisibility(View.VISIBLE);

                }
            }
        });

        question24Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question24Group.getCheckedRadioButtonId() == R.id.question24R1) {
                    question24Part2EditText.setVisibility(View.GONE);
                    question24Part2EditText.setText("N/A");
                    question24Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question24Part2EditText.setVisibility(View.VISIBLE);
                    question24Part2EditText.setText("");
                    question24Part2TextView.setVisibility(View.VISIBLE);
                }
            }
        });

        final Button questionsButton = (Button) findViewById(R.id.questionsButton);
        questionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK INFO FROM USEFUL INFO ACTIVITY

                String message = getIntent().getExtras().getString("Message");

                //FIND ALL OF THE CHECKED RADIO BUTTONS
                RadioButton question1Checked = findRadio(question1Group);
                RadioButton question2Checked = findRadio(question2Group);
                RadioButton question3Checked = findRadio(question3Group);
                RadioButton question4Checked = findRadio(question4Group);
                RadioButton question5Checked = findRadio(question5Group);
                RadioButton question6Checked = findRadio(question6Group);
                RadioButton question7Checked = findRadio(question7Group);
                RadioButton question8Checked = findRadio(question8Group);
                RadioButton question9Checked = findRadio(question9Group);
                RadioButton question10Checked = findRadio(question10Group);
                RadioButton question11Checked = findRadio(question11Group);
                RadioButton question12Checked = findRadio(question12Group);
                RadioButton question13Checked = findRadio(question13Group);
                RadioButton question14Checked = findRadio(question14Group);
                RadioButton question15Checked = findRadio(question15Group);
                RadioButton question16Checked = findRadio(question16Group);
                RadioButton question17Checked = findRadio(question17Group);
                RadioButton question18Checked = findRadio(question18Group);
                RadioButton question19Checked = findRadio(question19Group);
                RadioButton question20Checked = findRadio(question20Group);
                RadioButton question21Checked = findRadio(question21Group);
                RadioButton question22Checked = findRadio(question22Group);
                RadioButton question23Checked = findRadio(question23Group);
                RadioButton question24Checked = findRadio(question24Group);

//                RadioButton arra[] = {question1Checked, question2Checked, question3Checked};
//                for (RadioButton item : arra) {
//                    Log.v("Questions", item.getText().toString());
//                }

                //GET THE STRINGS OF THE RESPONSES
                if (
                        //CHECKING THAT THE USER PUT SOMETHING FOR EVERY FIELD
                                question1Checked != null
                                && question2Checked != null
                                && question3Checked != null
                                && question4Checked != null
                                && question5Checked != null
                                && question6Checked != null
                                && question7Checked != null
                                && question8Checked != null
                                && question9Checked != null
                                && question10Checked != null
                                && question11Checked != null
                                && question12Checked != null
                                && question13Checked != null
                                && question14Checked != null
                                && question15Checked != null
                                && question16Checked != null
                                && question17Checked != null
                                && question18Checked != null
                                && question19Checked != null
                                && question20Checked != null
                                && question21Checked != null
                                && question22Checked != null
                                && question23Checked != null
                                && question24Checked != null
                                && !checkEmpty(question25EditText)
                                && !checkEmpty(question1Part2EditText)
                                && !checkEmpty(question3Part2EditText)
                                && !checkEmpty(question13Part2EditText)
                                && !checkEmpty(question20Part2EditText)
                                && !checkEmpty(question24Part2EditText)
                        )
                {
                    //FIND TEXT VIEWS FOR THE PART 2 QUESTIONS
                    TextView question13Part2TextView = (TextView) findViewById(R.id.question13Part2Text);

                    //FIND THE REST OF THE TEXTVIEWS
                    TextView question25TextView = (TextView) findViewById(R.id.question25Text);


                    //CONCATENATE THE STRINGS NOW
                    message += addToMessage(concatenateRadio(getString(R.string.q1Text), question1Checked));
                    message += addToMessage(concatenateEdit(question1Part2TextView, question1Part2EditText));
                    message += addToMessage(concatenateRadio(getString(R.string.q2Text), question2Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q3Text), question3Checked));
                    message += addToMessage(concatenateEdit(question3Part2TextView, question3Part2EditText));
                    message += addToMessage(concatenateRadio(getString(R.string.q4Text), question4Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q5Text), question5Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q6Text), question6Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q7Text), question7Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q8Text), question8Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q9Text), question9Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q10Text), question10Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q11Text), question11Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q12Text), question12Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q13Text), question13Checked));
                    message += addToMessage(concatenateEdit(question13Part2TextView, question13Part2EditText));
                    message += addToMessage(concatenateRadio(getString(R.string.q14Text), question14Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q15Text), question15Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q16Text), question16Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q17Text), question17Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q18Text), question18Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q19Text), question19Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q20Text), question20Checked));
                    message += addToMessage(concatenateEdit(question20Part2TextView, question20Part2EditText));
                    message += addToMessage(concatenateRadio(getString(R.string.q21Text), question21Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q22Text), question22Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q23Text), question23Checked));
                    message += addToMessage(concatenateRadio(getString(R.string.q24Text), question24Checked));
                    message += addToMessage(concatenateEdit(question24Part2TextView, question24Part2EditText));
                    message += addToMessage(concatenateEdit(question25TextView, question25EditText));

                    Intent intent = new Intent(Questions.this, Observations.class);

                    //PACKING UP
                    intent.putExtra("Message", message);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(Questions.this, "Oops! Looks like you missed a question.", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    private boolean checkEmpty (EditText Text){

        return Text.getText().toString().trim().length() == 0;
    }

    private String concatenateRadio(String question, RadioButton response)
    {
        return (question + "\n" + response.getText().toString());
    }

    private String concatenateEdit(TextView question, EditText response){
        return (question.getText().toString() + "\n" + response.getText().toString());
    }

    private RadioButton findRadio(RadioGroup group) {
        return (RadioButton)findViewById(group.getCheckedRadioButtonId());
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private String addToMessage(String questionFull){
        return "\n\n" + questionFull;
    }
}
