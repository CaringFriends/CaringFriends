package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PersonalInfo extends AppCompatActivity {

    //UNPACK INFO FROM CHECK IN ACTIVITY HERE

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_personal_info);

        final Button personalInfoButton = (Button)findViewById(R.id.personalInfoButton);
        personalInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK
                String message = getIntent().getExtras().getString("Message");


                //NO NEW INFORMATION TO CARRY OVER, JUST RETRIEVE THE INTENT FROM CHECK IN AND
                //IMMEDIATELY PASS IT OVER
                Intent intent = new Intent(PersonalInfo.this, UsefulInfo.class);
                intent.putExtra("Message", message);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

}
