package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Questions extends AppCompatActivity {

    String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_questions);


        final Button questionsButton = (Button) findViewById(R.id.questionsButton);
        questionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK INFO FROM USEFUL INFO ACTIVITY

                String message = getIntent().getExtras().getString("Message");

                //FIND ALL OF THE RADIOGROUPS
                RadioGroup question1Group = (RadioGroup) findViewById(R.id.question1);
                RadioGroup question2Group = (RadioGroup) findViewById(R.id.question2);
                RadioGroup question3Group = (RadioGroup) findViewById(R.id.question3);
                RadioGroup question4Group = (RadioGroup) findViewById(R.id.question4);
                RadioGroup question5Group = (RadioGroup) findViewById(R.id.question5);
                RadioGroup question6Group = (RadioGroup) findViewById(R.id.question6);
                RadioGroup question7Group = (RadioGroup) findViewById(R.id.question7);
                RadioGroup question8Group = (RadioGroup) findViewById(R.id.question8);
                RadioGroup question9Group = (RadioGroup) findViewById(R.id.question9);
                RadioGroup question10Group = (RadioGroup) findViewById(R.id.question10);
                RadioGroup question11Group = (RadioGroup) findViewById(R.id.question11);
                RadioGroup question12Group = (RadioGroup) findViewById(R.id.question12);
                RadioGroup question13Group = (RadioGroup) findViewById(R.id.question13);
                RadioGroup question14Group = (RadioGroup) findViewById(R.id.question14);
                RadioGroup question15Group = (RadioGroup) findViewById(R.id.question15);
                RadioGroup question16Group = (RadioGroup) findViewById(R.id.question16);
                RadioGroup question17Group = (RadioGroup) findViewById(R.id.question17);
                RadioGroup question18Group = (RadioGroup) findViewById(R.id.question18);
                RadioGroup question19Group = (RadioGroup) findViewById(R.id.question19);
                RadioGroup question20Group = (RadioGroup) findViewById(R.id.question20);
                RadioGroup question21Group = (RadioGroup) findViewById(R.id.question21);
                RadioGroup question22Group = (RadioGroup) findViewById(R.id.question22);
                RadioGroup question23Group = (RadioGroup) findViewById(R.id.question23);
                RadioGroup question24Group = (RadioGroup) findViewById(R.id.question24);

                //FIND ALL OF THE EDITTEXT
                EditText question1Part2EditText = (EditText) findViewById(R.id.question1Part2EditText);
                EditText question3Part2EditText = (EditText) findViewById(R.id.question3Part2EditText);
                EditText question13Part2EditText = (EditText) findViewById(R.id.question13Part2EditText);
                EditText question20Part2EditText = (EditText) findViewById(R.id.question20Part2EditText);
                EditText question24Part2EditText = (EditText) findViewById(R.id.question24Part2EditText);
                EditText question25EditText = (EditText) findViewById(R.id.question25EditText);

                //FIND ALL OF THE CHECKED RADIO BUTTONS
                RadioButton question1Checked = findRadio(question1Group);
                RadioButton question2Checked = findRadio(question2Group);
                RadioButton question3Checked = findRadio(question3Group);
                RadioButton question4Checked = findRadio(question4Group);
                RadioButton question5Checked = findRadio(question5Group);
                RadioButton question6Checked = findRadio(question6Group);
                RadioButton question7Checked = findRadio(question7Group);
                RadioButton question8Checked = findRadio(question8Group);
                RadioButton question9Checked = findRadio(question9Group);
                RadioButton question10Checked = findRadio(question10Group);
                RadioButton question11Checked = findRadio(question11Group);
                RadioButton question12Checked = findRadio(question12Group);
                RadioButton question13Checked = findRadio(question13Group);
                RadioButton question14Checked = findRadio(question14Group);
                RadioButton question15Checked = findRadio(question15Group);
                RadioButton question16Checked = findRadio(question16Group);
                RadioButton question17Checked = findRadio(question17Group);
                RadioButton question18Checked = findRadio(question18Group);
                RadioButton question19Checked = findRadio(question19Group);
                RadioButton question20Checked = findRadio(question20Group);
                RadioButton question21Checked = findRadio(question21Group);
                RadioButton question22Checked = findRadio(question22Group);
                RadioButton question23Checked = findRadio(question23Group);
                RadioButton question24Checked = findRadio(question24Group);


                //GET THE STRINGS OF THE RESPONSES
                if (
                        //CHECKING THAT THE USER PUT SOMETHING FOR EVERY FIELD


                                question1Checked != null
                                && question2Checked != null
                                && question3Checked != null
                                && question4Checked != null
                                && question5Checked != null
                                && question6Checked != null
                                && question7Checked != null
                                && question8Checked != null
                                && question9Checked != null
                                && question10Checked != null
                                && question11Checked != null
                                && question12Checked != null
                                && question13Checked != null
                                && question14Checked != null
                                && question15Checked != null
                                && question16Checked != null
                                && question17Checked != null
                                && question18Checked != null
                                && question19Checked != null
                                && question20Checked != null
                                && question21Checked != null
                                && question22Checked != null
                                && question23Checked != null
                                && question24Checked != null
                                && !checkEmpty(question25EditText)
                                && !checkEmpty(question1Part2EditText)
                                && !checkEmpty(question3Part2EditText)
                                && !checkEmpty(question13Part2EditText)
                                && !checkEmpty(question20Part2EditText)
                                && !checkEmpty(question24Part2EditText)
                        )
                {
                    //FIND TEXT VIEWS FOR THE PART 2 QUESTIONS
                    TextView question1Part2TextView = (TextView) findViewById(R.id.question1Part2Text);
                    TextView question3Part2TextView = (TextView) findViewById(R.id.question3Part2Text);
                    TextView question13Part2TextView = (TextView) findViewById(R.id.question13Part2Text);
                    TextView question20Part2TextView = (TextView) findViewById(R.id.question20Part2Text);
                    TextView question24Part2TextView = (TextView) findViewById(R.id.question24Part2Text);

                    //FIND THE REST OF THE TEXTVIEWS
                    TextView question1TextView = (TextView) findViewById(R.id.question1Text);
                    TextView question2TextView = (TextView) findViewById(R.id.question2Text);
                    TextView question3TextView = (TextView) findViewById(R.id.question3Text);
                    TextView question4TextView = (TextView) findViewById(R.id.question4Text);
                    TextView question5TextView = (TextView) findViewById(R.id.question5Text);
                    TextView question6TextView = (TextView) findViewById(R.id.question6Text);
                    TextView question7TextView = (TextView) findViewById(R.id.question7Text);
                    TextView question8TextView = (TextView) findViewById(R.id.question8Text);
                    TextView question9TextView = (TextView) findViewById(R.id.question9Text);
                    TextView question10TextView = (TextView) findViewById(R.id.question10Text);
                    TextView question11TextView = (TextView) findViewById(R.id.question11Text);
                    TextView question12TextView = (TextView) findViewById(R.id.question12Text);
                    TextView question13TextView = (TextView) findViewById(R.id.question13Text);
                    TextView question14TextView = (TextView) findViewById(R.id.question14Text);
                    TextView question15TextView = (TextView) findViewById(R.id.question15Text);
                    TextView question16TextView = (TextView) findViewById(R.id.question16Text);
                    TextView question17TextView = (TextView) findViewById(R.id.question17Text);
                    TextView question18TextView = (TextView) findViewById(R.id.question18Text);
                    TextView question19TextView = (TextView) findViewById(R.id.question19Text);
                    TextView question20TextView = (TextView) findViewById(R.id.question20Text);
                    TextView question21TextView = (TextView) findViewById(R.id.question21Text);
                    TextView question22TextView = (TextView) findViewById(R.id.question22Text);
                    TextView question23TextView = (TextView) findViewById(R.id.question23Text);
                    TextView question24TextView = (TextView) findViewById(R.id.question24Text);
                    TextView question25TextView = (TextView) findViewById(R.id.question25Text);
                    //Don't need to create these textview objects just to take their text, would be better
                    //off creating string resources and using getString(R.string.whatever)

                    //CONCATENATE THE STRINGS NOW
                    message += addToMessage(concatenateRadio(question1TextView, question1Checked));
                    message += addToMessage(concatenateEdit(question1Part2TextView, question1Part2EditText));
                    message += addToMessage(concatenateRadio(question2TextView, question2Checked));
                    message += addToMessage(concatenateRadio(question3TextView, question3Checked));
                    message += addToMessage(concatenateEdit(question3Part2TextView, question3Part2EditText));
                    message += addToMessage(concatenateRadio(question4TextView, question4Checked));
                    message += addToMessage(concatenateRadio(question5TextView, question5Checked));
                    message += addToMessage(concatenateRadio(question6TextView, question6Checked));
                    message += addToMessage(concatenateRadio(question7TextView, question7Checked));
                    message += addToMessage(concatenateRadio(question8TextView, question8Checked));
                    message += addToMessage(concatenateRadio(question9TextView, question9Checked));
                    message += addToMessage(concatenateRadio(question10TextView, question10Checked));
                    message += addToMessage(concatenateRadio(question11TextView, question11Checked));
                    message += addToMessage(concatenateRadio(question12TextView, question12Checked));
                    message += addToMessage(concatenateRadio(question13TextView, question13Checked));
                    message += addToMessage(concatenateEdit(question13Part2TextView, question13Part2EditText));
                    message += addToMessage(concatenateRadio(question14TextView, question14Checked));
                    message += addToMessage(concatenateRadio(question15TextView, question15Checked));
                    message += addToMessage(concatenateRadio(question16TextView, question16Checked));
                    message += addToMessage(concatenateRadio(question17TextView, question17Checked));
                    message += addToMessage(concatenateRadio(question18TextView, question18Checked));
                    message += addToMessage(concatenateRadio(question19TextView, question19Checked));
                    message += addToMessage(concatenateRadio(question20TextView, question20Checked));
                    message += addToMessage(concatenateEdit(question20Part2TextView, question20Part2EditText));
                    message += addToMessage(concatenateRadio(question21TextView, question21Checked));
                    message += addToMessage(concatenateRadio(question22TextView, question22Checked));
                    message += addToMessage(concatenateRadio(question23TextView, question23Checked));
                    message += addToMessage(concatenateRadio(question24TextView, question24Checked));
                    message += addToMessage(concatenateEdit(question24Part2TextView, question24Part2EditText));
                    message += addToMessage(concatenateEdit(question25TextView, question25EditText));

                    Intent intent = new Intent(Questions.this, Observations.class);

                    //PACKING UP
                    intent.putExtra("Message", message);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(Questions.this, "Oops! Looks like you missed a question.", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    private boolean checkEmpty (EditText Text){

        return Text.getText().toString().trim().length() == 0;
    }

    private String concatenateRadio(TextView question, RadioButton response)
    {
        return (question.getText().toString() + "\n" + response.getText().toString());
    }

    private String concatenateEdit(TextView question, EditText response){
        return (question.getText().toString() + "\n" + response.getText().toString());
    }

    private RadioButton findRadio(RadioGroup group) {
        return (RadioButton)findViewById(group.getCheckedRadioButtonId());
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private String addToMessage(String questionFull){
        return "\n\n" + questionFull;
    }
}
