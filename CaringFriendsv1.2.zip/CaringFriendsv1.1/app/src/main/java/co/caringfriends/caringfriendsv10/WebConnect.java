package co.caringfriends.caringfriendsv10;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface WebConnect{
    @POST("e/1FAIpQLSeSz1VRYr-o52TmWej8wpXq72yx-ZWsunUXAdpoh_UKhbacUQ/formResponse")
    @FormUrlEncoded
    Call<Void> completeQuestionnaire(

            @Field("entry.1689460411") String Input
    );
}