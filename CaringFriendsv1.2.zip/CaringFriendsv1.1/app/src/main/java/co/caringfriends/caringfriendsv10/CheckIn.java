package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class CheckIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-RobotoRegular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
        setContentView(R.layout.activity_check_in);
        //YOU NEED THESE TWO TAGS FOR THIS TO WORK, MUST APPLY THIS TO ALL CLASSES

        //UNPACK IS EMPTY, NO DATA RECEIVED FROM PREVIOUS ACTIVITY

        final Button checkInButton = (Button)findViewById(R.id.checkInButton);
        checkInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText nameOfOlderAdult = (EditText)findViewById(R.id.nameOfOlderAdult);
                EditText nameOfVisitingFriend = (EditText)findViewById(R.id.nameOfVisitingFriend);
                EditText dateOfVisit = (EditText)findViewById(R.id.dateOfVisit);
                EditText cityOfVisit = (EditText)findViewById(R.id.cityOfVisit);

                String nameText = "Name of Older Adult:";
                String friendText = "Name of Visiting Friend:";
                String dateText = "Date of Visit:";
                String cityText = "City of Visit:";

                Intent intent = new Intent(CheckIn.this, PersonalInfo.class);

                if (
                        !checkEmpty(nameOfOlderAdult) && !checkEmpty(nameOfVisitingFriend) &&
                                !checkEmpty(dateOfVisit) && !checkEmpty(cityOfVisit)
                        )
                {
                    //PACK UP
                    String message = createSummary(nameText, nameOfOlderAdult,
                            friendText, nameOfVisitingFriend,
                            dateText, dateOfVisit,
                            cityText, cityOfVisit);
                    intent.putExtra("Message", message);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(CheckIn.this, "Oops! Looks like you missed a field.", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    public String createSummary(String nameText, EditText nameEdit,
                                String friendText, EditText friendEdit,
                                String dateText, EditText dateEdit,
                                String cityText, EditText cityEdit) {

        String message = nameText + '\n' + nameEdit.getText().toString() + "\n\n";
        message += friendText + '\n' + friendEdit.getText().toString() + "\n\n";
        message += dateText + '\n' + dateEdit.getText().toString() + "\n\n";
        message += cityText + '\n' + cityEdit.getText().toString()+ "\n\n";
        return message;
    }

    public boolean checkEmpty (EditText Text){
        return Text.getText().toString().trim().length() == 0;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
