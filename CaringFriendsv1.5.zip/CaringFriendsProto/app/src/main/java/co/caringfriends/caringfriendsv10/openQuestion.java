package co.caringfriends.caringfriendsv10;

import android.widget.EditText;

/**
 * Created by Mark on 4/18/2017.
 */

public class openQuestion extends question{

    private String mQuestionResponse;

    //This is in the question class.
    openQuestion(String questionText, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        super(questionText, hasDependentQuestion, isDependentQuestion,target);
    }

    public String getmQuestionResponse() {
        return mQuestionResponse;
    }

    public void setmQuestionResponse(String response) {
        mQuestionResponse = response;
    }

}
