package co.caringfriends.caringfriendsv10;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Mark on 6/13/2017.
 */

public class InformationFragmentPagerAdapter extends FragmentPagerAdapter {

    public InformationFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    //hand back the correct fragment
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new PersonalInfoFragment();
        } else {
            return new UsefulInfoFragment();
        }
    }

    //we know the number of tabs in this viewPager is 2
    @Override
    public int getCount() {
        return 2;
    }
}