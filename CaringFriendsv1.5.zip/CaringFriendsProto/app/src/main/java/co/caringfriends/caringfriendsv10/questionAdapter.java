package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Merged adapter class to fit both question types into one list view.
 * Created by Mark on 6/8/2017.
 */


public class questionAdapter extends ArrayAdapter<question> {

    question currentQuestion;
    multiQuestion currentMulti;
    openQuestion currentOpen;

    public questionAdapter(Activity context, ArrayList<question> questions){
        super(context, 0 ,questions);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        //Use this layout if the object subclass coming is open-ended
        currentQuestion = getItem(position);

        if(currentQuestion.getmObjectType().equals("openEnded")){

            //if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.open_ended_list, parent, false);
            //}
            //reset the view to visible in case it got set to invisible
            listItemView.setVisibility(View.VISIBLE);

            currentQuestion = (openQuestion)getItem(position);

            TextView openTextView = (TextView)listItemView.findViewById(R.id.openTextView);
            openTextView.setText(currentQuestion.getmQuestionText());

            final EditText openEditText = (EditText)listItemView.findViewById(R.id.openEditText);
            final CheckBox openCheckBox = (CheckBox)listItemView.findViewById(R.id.openCheckbox);

            openEditText.setHint("Enter something...");
            openCheckBox.setText("Skip this question");

            openCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (openCheckBox.isChecked()){
                        openEditText.setText("Question skipped...");
                        openEditText.setEnabled(false);
                        //disable the edittext if they hit the check to skip
                    }
                    else {
                        openEditText.setText("");
                        openEditText.setHint("Enter something...");
                        openEditText.setEnabled(true);
                    }
                }
            });

            //if it's a dependent question, hide it.
            if (currentQuestion.getIsDependentQuestion()){
                listItemView.setVisibility(View.GONE);
            }

        }

        //Use this layout if the object sublass coming is multiple choice
        if(currentQuestion.getmObjectType().equals("multiChoice")){

            //if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.multiple_choice_list, parent, false);
            //}
            //reset the view to visible in case it got set to invisible
            listItemView.setVisibility(View.VISIBLE);

            currentMulti = (multiQuestion)currentQuestion;

            TextView questionTextView = (TextView)listItemView.findViewById(R.id.questionTextView);
            questionTextView.setText(currentQuestion.getmQuestionText());

            final RadioGroup questionRadioGroup = (RadioGroup)listItemView.findViewById(R.id.questionRadioGroup);
            RadioButton questionOption1 = (RadioButton)listItemView.findViewById(R.id.questionOption1);
            RadioButton questionOption2 = (RadioButton)listItemView.findViewById(R.id.questionOption2);
            RadioButton questionOption3 = (RadioButton)listItemView.findViewById(R.id.questionOption3);
            RadioButton questionOption4 = (RadioButton)listItemView.findViewById(R.id.questionOption4);
            RadioButton questionOption5 = (RadioButton)listItemView.findViewById(R.id.questionOption5);

            //techincally those views are there, just not visible or accessible to the user.
            if(currentMulti.getmNumberOfOptions() == 3){
                questionOption1.setText(currentMulti.getmOption1Text());
                questionOption2.setText(currentMulti.getmOption2Text());
                questionOption3.setText(currentMulti.getmSkippedText());
                questionOption4.setVisibility(View.GONE);
                questionOption5.setVisibility(View.GONE);
            }
            else if(currentMulti.getmNumberOfOptions() == 4) {
                questionOption1.setText(currentMulti.getmOption1Text());
                questionOption2.setText(currentMulti.getmOption2Text());
                questionOption3.setText(currentMulti.getmOption3Text());
                questionOption4.setText(currentMulti.getmSkippedText());
                questionOption5.setVisibility(View.GONE);
            }
            else if(currentMulti.getmNumberOfOptions() == 5) {
                questionOption1.setText(currentMulti.getmOption1Text());
                questionOption2.setText(currentMulti.getmOption2Text());
                questionOption3.setText(currentMulti.getmOption3Text());
                questionOption4.setText(currentMulti.getmOption4Text());
                questionOption5.setText(currentMulti.getmSkippedText());
            }


        questionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                currentMulti.setRadioGroup(questionRadioGroup);
                RadioButton checkedButton = (RadioButton)(group.findViewById(checkedId));
                currentMulti.setResponse(checkedButton.getText().toString());
                if(!currentMulti.getTarget().equals("None")){
                    //if it has a target, then it has a dependent question
                    Log.v("XXX", currentMulti.getResponse());
                    //if the target matches the response, reveal the dependent question
                    if(currentMulti.getTarget().equals(currentMulti.getResponse())){

                        Log.v("XXX", "passed");
                    }
                    else{
                    }
                }
            }
        });
            //if it's a dependent question, hide it.
            if (currentQuestion.getIsDependentQuestion()){
                listItemView.setVisibility(View.GONE);
            }

        }
        return listItemView;
    }
}
