package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class Observations extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);

        //this class is not used either, needs to be removed.  remnant from previous version of app
        //used for testing purposes
        //TODO: remove this activity
        ArrayList<question> questions = new ArrayList<>();
//        questions.add(new question(getString(R.string.obs1Q), "Clean", "Reasonable", "Somewhat Messy", "Really Needs Help"));
//        questions.add(new question(getString(R.string.obs2Q), "Clean", "Reasonable", "Somewhat Messy", "Really Needs Help"));

        questionAdapter adapter = new questionAdapter(Observations.this, questions);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);

        Button button = new Button(this);
        listView.addFooterView(button);
        button.setText(R.string.buttonText);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}