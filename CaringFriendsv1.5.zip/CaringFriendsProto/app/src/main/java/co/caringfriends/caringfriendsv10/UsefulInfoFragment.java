package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Mark on 6/13/2017.
 */

public class UsefulInfoFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //TODO: Moved this to the class ahead.  We need a splash page with loading.  Look at udemy firebase
        //Want to create our array list of questions first and foremost
        final ArrayList<question> questions  = FirebaseRetrieve.retrieveData("questions");
        final ArrayList<question> observations = FirebaseRetrieve.retrieveData("observations");

        View rootview = inflater.inflate(R.layout.fragment_useful_info, container, false);
        Button button = (Button)rootview.findViewById(R.id.infoButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FormActivity.class);
                intent.putExtra("questionsList", questions);
                intent.putExtra("observationsList", observations);
                startActivity(intent);
            }
        });

        return rootview;
    }

    //TODO: add in all of the stuff that needs to go on in the useful info activity
}
