package co.caringfriends.caringfriendsv10;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Mark on 6/13/2017.
 */

public class QuestionsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate((R.layout.list_layout), container, false);

        final ArrayList<question> questions = (ArrayList<question>)getActivity().getIntent().getExtras().getSerializable("questionsList");

        final questionAdapter adapter = new questionAdapter(getActivity(), questions);

        final ListView listView = (ListView)rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                question clickedQuestion = questions.get(position);
                //if it has a target, see if the
                if(!clickedQuestion.getTarget().equals("None")){
                    //if it has a target, then it's multiple choice, cast it to a multiple choice
                    multiQuestion clickedMultiQuestion = (multiQuestion)clickedQuestion;
                    Log.v("XXX", clickedMultiQuestion.getResponse());
                    View clickedView = ViewUtils.getViewByPosition(position + 1, listView);
                    //if the target matches the response, reveal the dependent question
                    if(clickedMultiQuestion.getTarget().equals(clickedMultiQuestion.getResponse())){

                        clickedView.setVisibility(View.VISIBLE);
                        Log.v("XXX", "passed");
                    }
                    else{
                        clickedView.setVisibility(View.GONE);
                    }
                }
            }
        });

        return rootView;
    }
}
