package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;

public class FormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        final TabLayout tabLayout = (TabLayout)findViewById(R.id.tab_layout);

        //Get our adapter to fit these fragments to our activity
        FormFragmentPagerAdapter infoAdapter = new FormFragmentPagerAdapter(getSupportFragmentManager());

        //Add in our tabs to our top bar
        tabLayout.addTab(tabLayout.newTab().setText("Questions").setIcon(R.drawable.ic_help_outline_white_24dp));
        tabLayout.addTab(tabLayout.newTab().setText("Observations").setIcon(R.drawable.ic_visibility_white_24dp));
        tabLayout.addTab(tabLayout.newTab().setText("Notes").setIcon(R.drawable.ic_assignment_white_24dp));

        final ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setAdapter(infoAdapter);

        //TODO: Need to define this listener elsewhere so we can remove it in the onclick of button
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tabLayout.getSelectedTabPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        ListView listView = (ListView)findViewById(R.id.list);
    }

    //calling super to give the form fragment a chance to handle the onActivityResult
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }


}
