package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Class meant to be applied to all multiple choice questions.
 * Created by Mark on 4/18/2017.
 */
//TODO: delete this class.  It has been merged into the questionAdapter class
public class multiAdapter extends ArrayAdapter<multiQuestion> {


    public multiAdapter(Activity context, ArrayList<multiQuestion> multiQuestions) {
        super(context, 0 ,multiQuestions);
        //Here, the term super means we are calling the superclass's constructor, meaning that
        //we are just going to use array adapter's constructor
    }

    //private RadioGroup questionRadioGroup;
    private View listItemView;

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.multiple_choice_list, parent, false);
        }

        final multiQuestion currentQuestion = getItem(position);

        TextView questionTextView = (TextView)listItemView.findViewById(R.id.questionTextView);
        questionTextView.setText(currentQuestion.getmQuestionText());

        //questionRadioGroup = (RadioGroup)listItemView.findViewById(R.id.questionRadioGroup);
        RadioButton questionOption1 = (RadioButton)listItemView.findViewById(R.id.questionOption1);
        RadioButton questionOption2 = (RadioButton)listItemView.findViewById(R.id.questionOption2);
        RadioButton questionOption3 = (RadioButton)listItemView.findViewById(R.id.questionOption3);
        RadioButton questionOption4 = (RadioButton)listItemView.findViewById(R.id.questionOption4);
        RadioButton questionOption5 = (RadioButton)listItemView.findViewById(R.id.questionOption5);

        //determine which style of multiple choice it is and display the appropriate number of options.
        //this can be easily condensed, but just leaving it here for now

        //TODO: condense this
//        if(currentQuestion.getmNumberOfOptions() == 3){
//            questionOption1.setText(currentQuestion.getmOption1Text());
//            questionOption2.setText(currentQuestion.getmOption2Text());
//            questionOption3.setText(currentQuestion.getmSkippedText());
//            questionOption4.setVisibility(View.GONE);
//            questionOption5.setVisibility(View.GONE);
//        }
//        else if(currentQuestion.getmNumberOfOptions() == 4) {
//            questionOption1.setText(currentQuestion.getmOption1Text());
//            questionOption2.setText(currentQuestion.getmOption2Text());
//            questionOption3.setText(currentQuestion.getmOption3Text());
//            questionOption4.setText(currentQuestion.getmSkippedText());
//            questionOption5.setVisibility(View.GONE);
//        }
//        else if(currentQuestion.getmNumberOfOptions() == 5) {
//            questionOption1.setText(currentQuestion.getmOption1Text());
//            questionOption2.setText(currentQuestion.getmOption2Text());
//            questionOption3.setText(currentQuestion.getmOption3Text());
//            questionOption4.setText(currentQuestion.getmOption4Text());
//            questionOption5.setText(currentQuestion.getmSkippedText());
//        }
        return listItemView;
    }
}