package co.caringfriends.caringfriendsv10;

import java.io.Serializable;

/**
 * This is the superclass of both multiQuestion and openQuestion.  Attempting to implement into one listview.
 * Created by Mark on 6/8/2017.
 */

//let us pass this through intents using serializable
public class question implements Serializable{

    private String mQuestionText;
    private String mObjectType;
    private String mTarget;
    private Boolean mHasDependentQuestion;
    private Boolean mIsDependentQuestion;

    public String getmQuestionText(){
        return mQuestionText;
    }

    public void setmQuestionText(String questionText) {
        mQuestionText = questionText;
    }

    //open-ended question constructor
    question(String questionText, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        mQuestionText = questionText;
        mObjectType = "openEnded";
        mHasDependentQuestion = hasDependentQuestion;
        mIsDependentQuestion = isDependentQuestion;
        mTarget = target;
    }

    //multi-choice question constructors
    question(String questionText, String option1, String option2, String option3, String option4, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        mQuestionText = questionText;
        mObjectType = "multiChoice";
        mHasDependentQuestion = hasDependentQuestion;
        mIsDependentQuestion = isDependentQuestion;
        mTarget = target;
    }

    question(String questionText, String option1, String option2, String option3, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        mQuestionText = questionText;
        mObjectType = "multiChoice";
        mHasDependentQuestion = hasDependentQuestion;
        mIsDependentQuestion = isDependentQuestion;
        mTarget = target;
    }

    question(String questionText, String option1, String option2, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {

        mQuestionText = questionText;
        mObjectType = "multiChoice";
        mHasDependentQuestion = hasDependentQuestion;
        mIsDependentQuestion = isDependentQuestion;
        mTarget = target;
    }

    public String getmObjectType() {
        return mObjectType;
    }

    public String getTarget() {
        return mTarget;
    }

    public Boolean getHasDependentQuestion() {
        return mHasDependentQuestion;
    }

    public Boolean getIsDependentQuestion() {
        return mIsDependentQuestion;
    }
}