package co.caringfriends.caringfriendsv10;

import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * Created by Mark on 4/18/2017.
 */

public class multiQuestion extends question{
    //extending the class gives us the context we need to use findviewbyid

    private String mQuestionText;
    private RadioGroup mQuestionGroup;
    private String mOption1Text;
    private String mOption2Text;
    private String mOption3Text;
    private String mOption4Text;
    private String mResponse;
    private int mNumberOfOptions;

    //these three constructors are simply the various types of multiple choice questions we can have,
    //each with a different number of options
    public multiQuestion(String questionText, String option1, String option2, String option3, String option4, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        super(questionText, option1, option2, option3, option4, hasDependentQuestion, isDependentQuestion, target);
        mQuestionText = questionText;
        mOption1Text = option1;
        mOption2Text = option2;
        mOption3Text = option3;
        mOption4Text = option4;
        mNumberOfOptions = 5;
    }

    public multiQuestion(String questionText, String option1, String option2, String option3, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        super(questionText, option1, option2, option3, hasDependentQuestion, isDependentQuestion, target);
        mQuestionText = questionText;
        mOption1Text = option1;
        mOption2Text = option2;
        mOption3Text = option3;
        mNumberOfOptions = 4;
    }

    public multiQuestion(String questionText, String option1, String option2, Boolean hasDependentQuestion, Boolean isDependentQuestion, String target) {
        super(questionText, option1, option2, hasDependentQuestion, isDependentQuestion, target);
        mQuestionText = questionText;
        mOption1Text = option1;
        mOption2Text = option2;
        mNumberOfOptions = 3;
    }

    public String getResponse() {
        return mResponse;
    }

    public void setResponse(String response) {
        mResponse = response;
    }

    public String getmOption1Text() {
        return mOption1Text;
    }

    public String getmOption2Text() {
        return mOption2Text;
    }

    public String getmOption3Text() {
        return mOption3Text;
    }

    public String getmOption4Text() {
        return mOption4Text;
    }

    public int getmNumberOfOptions() {
        return mNumberOfOptions;
    }

    public void setRadioGroup(RadioGroup radioGroup) {
        mQuestionGroup = radioGroup;
    }

    public RadioGroup getmQuestionGroup() {
        return mQuestionGroup;
    }

    public String getmSkippedText() {
        return "Skip this question...";
    }
}
