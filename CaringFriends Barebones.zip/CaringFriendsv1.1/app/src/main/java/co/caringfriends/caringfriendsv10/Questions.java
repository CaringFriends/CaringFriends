package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;


import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Questions extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());
        setContentView(R.layout.activity_questions);

        final RadioGroup question1Group = (RadioGroup) findViewById(R.id.question1);
        final RadioGroup question3Group = (RadioGroup) findViewById(R.id.question3);
        final RadioGroup question20Group = (RadioGroup) findViewById(R.id.question20);
        final RadioGroup question24Group = (RadioGroup) findViewById(R.id.question24);

        final EditText question1Part2EditText = (EditText) findViewById(R.id.question1Part2EditText);
        final EditText question3Part2EditText = (EditText) findViewById(R.id.question3Part2EditText);
        final EditText question20Part2EditText = (EditText) findViewById(R.id.question20Part2EditText);
        final EditText question24Part2EditText = (EditText) findViewById(R.id.question24Part2EditText);

        final TextView question1Part2TextView = (TextView) findViewById(R.id.question1Part2Text);
        final TextView question3Part2TextView = (TextView) findViewById(R.id.question3Part2Text);

        final TextView question20Part2TextView = (TextView) findViewById(R.id.question20Part2Text);
        final TextView question24Part2TextView = (TextView) findViewById(R.id.question24Part2Text);

        question1Part2EditText.setVisibility(View.GONE);
        question1Part2TextView.setVisibility(View.GONE);

        question3Part2EditText.setVisibility(View.GONE);
        question3Part2TextView.setVisibility(View.GONE);

        question20Part2EditText.setVisibility(View.GONE);
        question20Part2TextView.setVisibility(View.GONE);

        question24Part2EditText.setVisibility(View.GONE);
        question24Part2TextView.setVisibility(View.GONE);

        question1Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question1Group.getCheckedRadioButtonId() == R.id.question1R4){
                    question1Part2EditText.setText("N/A");
                    question1Part2EditText.setVisibility(View.GONE);
                    question1Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question1Part2EditText.setVisibility(View.VISIBLE);
                    question1Part2EditText.setText("");
                    question1Part2TextView.setVisibility(View.VISIBLE);
                }
            }
        });

        question3Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question3Group.getCheckedRadioButtonId() != R.id.question3R5) {
                    question3Part2EditText.setVisibility(View.GONE);
                    question3Part2EditText.setText("N/A");
                    question3Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question3Part2EditText.setVisibility(View.VISIBLE);
                    question3Part2EditText.setText("");
                    question3Part2TextView.setVisibility(View.VISIBLE);

                }
            }
        });

        question20Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question20Group.getCheckedRadioButtonId() != R.id.question20R1) {
                    question20Part2EditText.setVisibility(View.GONE);
                    question20Part2EditText.setText("N/A");
                    question20Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question20Part2EditText.setVisibility(View.VISIBLE);
                    question20Part2EditText.setText("");
                    question20Part2TextView.setVisibility(View.VISIBLE);

                }
            }
        });

        question24Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (question24Group.getCheckedRadioButtonId() == R.id.question24R1) {
                    question24Part2EditText.setVisibility(View.GONE);
                    question24Part2EditText.setText("N/A");
                    question24Part2TextView.setVisibility(View.GONE);
                }
                else {
                    question24Part2EditText.setVisibility(View.VISIBLE);
                    question24Part2EditText.setText("");
                    question24Part2TextView.setVisibility(View.VISIBLE);
                }
            }
        });

        final Button questionsButton = (Button) findViewById(R.id.questionsButton);
        questionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent intent = new Intent(Questions.this, Observations.class);
                    startActivity(intent);
                }
        });

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
